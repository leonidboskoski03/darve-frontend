# @darve/contracts

Public Zod schemas, request/response/event shapes and safe exported types. Never expose provider credentials, Prisma rows or server clients. Read the relevant [API/DTO catalogue](../../docs/API_DTO_COMPATIBILITY_CATALOGUE.md) section.

[Documentation map](../../docs/README.md) · [Mandatory architecture](../../docs/ARCHITECTURE.md) · [Workflow](../../docs/WORKFLOW.md) · [Historical package notes](../../docs/archive/PACKAGE_READMES_2026-10-05.md#contracts).
